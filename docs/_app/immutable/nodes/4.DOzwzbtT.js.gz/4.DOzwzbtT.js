import{s as d,n as a}from"../chunks/scheduler.OL_oRLK1.js";import{S as m,i as v,e as h,f as u,c as f,g as p,j as _,n as r,a as l,d as o}from"../chunks/index.Ci40RFbN.js";function x(c){let e,n='<div id="main" class="svelte-ir4qo3"><a href="../slides/onebrc">Slides</a></div>',s;return{c(){e=h("div"),e.innerHTML=n,s=u(`

 -->`),this.h()},l(t){e=f(t,"DIV",{id:!0,class:!0,"data-svelte-h":!0}),p(e)!=="svelte-7vrxh6"&&(e.innerHTML=n),s=_(t,`

 -->`),this.h()},h(){r(e,"id","background"),r(e,"class","svelte-ir4qo3")},m(t,i){l(t,e,i),l(t,s,i)},p:a,i:a,o:a,d(t){t&&(o(e),o(s))}}}class S extends m{constructor(e){super(),v(this,e,null,x,d,{})}}export{S as component};
