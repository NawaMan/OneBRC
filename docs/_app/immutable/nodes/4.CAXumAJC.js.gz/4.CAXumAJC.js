import{s as c,n as a}from"../chunks/scheduler.DJUZaEzB.js";import{S as m,i as u,e as v,f,c as h,g as p,j as _,n as l,a as r,d as o}from"../chunks/index.4LyIrb68.js";function x(d){let e,i='<div id="main" class="svelte-ir4qo3"><a href="../slides">Slides</a></div>',s;return{c(){e=v("div"),e.innerHTML=i,s=f(`

 -->`),this.h()},l(t){e=h(t,"DIV",{id:!0,class:!0,"data-svelte-h":!0}),p(e)!=="svelte-828zby"&&(e.innerHTML=i),s=_(t,`

 -->`),this.h()},h(){l(e,"id","background"),l(e,"class","svelte-ir4qo3")},m(t,n){r(t,e,n),r(t,s,n)},p:a,i:a,o:a,d(t){t&&(o(e),o(s))}}}class S extends m{constructor(e){super(),u(this,e,null,x,c,{})}}export{S as component};
