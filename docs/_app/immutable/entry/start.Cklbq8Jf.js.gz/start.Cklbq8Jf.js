import{a as t}from"../chunks/entry.SXVJZqZr.js";export{t as start};
