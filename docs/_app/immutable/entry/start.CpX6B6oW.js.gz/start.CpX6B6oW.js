import{a as t}from"../chunks/entry.CT6oO0Hw.js";export{t as start};
