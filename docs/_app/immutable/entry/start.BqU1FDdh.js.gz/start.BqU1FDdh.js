import{a as t}from"../chunks/entry.E2n1f7bd.js";export{t as start};
