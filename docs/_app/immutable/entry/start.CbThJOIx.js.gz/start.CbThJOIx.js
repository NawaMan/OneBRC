import{a as t}from"../chunks/entry.W2ehZytS.js";export{t as start};
