import{a as t}from"../chunks/entry.Cza7bDt4.js";export{t as start};
