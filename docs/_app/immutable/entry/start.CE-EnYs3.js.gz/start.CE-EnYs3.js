import{a as t}from"../chunks/entry.BVdOGV3o.js";export{t as start};
