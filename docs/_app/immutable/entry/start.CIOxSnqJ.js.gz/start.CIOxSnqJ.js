import{a as t}from"../chunks/entry.J29Gn7fn.js";export{t as start};
