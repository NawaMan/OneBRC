import{a as t}from"../chunks/entry.DADGMTaW.js";export{t as start};
