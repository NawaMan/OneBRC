import{a as t}from"../chunks/entry.C61q55VR.js";export{t as start};
