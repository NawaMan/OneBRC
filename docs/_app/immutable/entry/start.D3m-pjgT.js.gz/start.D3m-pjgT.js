import{a as t}from"../chunks/entry.ByxZbAyP.js";export{t as start};
