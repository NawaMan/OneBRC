import{a as t}from"../chunks/entry.CzSVkE8H.js";export{t as start};
